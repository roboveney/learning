# T3_README

-copy the entire folder into the ~/catkin_ws/src file of a computer that is set up for ROS
-run catkin_make and source the build
-run the following lines of code
	$ roscore
	$ rosrun turtlesim turtlesim_node
	$ rosrun mines_veney_christina mines_veney_christina.py 


simple_create
=============

A very basic project to load a iRobot Create model into Gazebo and drive it from rospy.

Running
-------

Assuming a properly setup ROS, catkin workspace, and Gazebo, this should be all that is necessary:

`roslaunch simple_create create_world.launch`
